
source("DBDA2E-utilities.R")





#----------------------------------------------------------------------------------
# Function Definitions for MCMC chain
#----------------------------------------------------------------------------------
genMCMC = function( data , prior_list, numSavedSteps=50000 , saveName=NULL ) { 
  require(rjags)

  yA = data$director_model
  yB = data$imdb_rate_model
  yC = data$action_model
  
  y = c(yA, yB, yC)
  s = c(rep(1, length(yA)), rep(2, length(yB)), rep(3, length(yC)))
  
  # Do some checking that data make sense:
  if ( any( y!=0 & y!=1) ) { stop("All y values must be 0 or 1.") }
  
  Ntotal = length(y)
  Nsubj = length(unique(s))
  
  
  # calculating shape parameters (a,b) for beta distribution
  # for theta1
  a1 = round(prior_list[1],2)*100
  b1 = 100-a1
  
  # for theta2
  a2 = round(prior_list[2],2)*100
  b2 = 100-a2
  
  # for theta3
  a3 = round(prior_list[3],2)*100
  b3 = 100-a3
  
  # Specify the data in a list, for later shipment to JAGS:
  dataList = list(
    y = y,
    s = s,
    Ntotal = Ntotal,
    a1 = a1,
    b1 = b1,
    a2 = a2,
    b2 = b2,
    a3 = a3,
    b3 = b3
  )
  #-----------------------------------------------------------------------------
  # THE MODEL.
  modelString = "
  model {
  for ( i in 1:Ntotal ) {
  y[i] ~ dbern( theta[s[i]] )
  }
  theta[1] ~ dbeta(a1, b1)
  theta[2] ~ dbeta(a2, b2)
  theta[3] ~ dbeta(a3, b3)
  }
  " # close quote for modelString
  writeLines( modelString , con="TEMPmodel.txt" )
  #-----------------------------------------------------------------------------
  # INTIALIZE THE CHAINS.

  initsList = function() {
    thetaInit = rep(0,Nsubj)
    for ( sIdx in 1:Nsubj ) { # for each subject
      includeRows = ( s == sIdx ) # identify rows of this subject
      yThisSubj = y[includeRows]  # extract data of this subject
      resampledY = sample( yThisSubj , replace=TRUE ) # resample
      thetaInit[sIdx] = sum(resampledY)/length(resampledY) 
    }
    thetaInit = 0.001+0.998*thetaInit # keep away from 0,1
    return( list( theta=thetaInit ) )
  }
  #-----------------------------------------------------------------------------
  # RUN THE CHAINS
  parameters = c( "theta")     # The parameters to be monitored
  adaptSteps = 500             # Number of steps to adapt the samplers
  burnInSteps = 500            # Number of steps to burn-in the chains
  nChains = 4                  # nChains should be 2 or more for diagnostics 
  thinSteps = 1
  nIter = ceiling( ( numSavedSteps * thinSteps ) / nChains )
  # Create, initialize, and adapt the model:
  jagsModel = jags.model( "TEMPmodel.txt" , data=dataList , inits=initsList , 
                          n.chains=nChains , n.adapt=adaptSteps )
  # Burn-in:
  cat( "Burning in the MCMC chain...\n" )
  update( jagsModel , n.iter=burnInSteps )
  # The saved MCMC chain:
  cat( "Sampling final MCMC chain...\n" )
  codaSamples = coda.samples( jagsModel , variable.names=parameters , 
                              n.iter=nIter , thin=thinSteps )
  # resulting codaSamples object has these indices: 
  #   codaSamples[[ chainIdx ]][ stepIdx , paramIdx ]
  if ( !is.null(saveName) ) {
    save( codaSamples , file=paste(saveName,"Mcmc.Rdata",sep="") )
  }
  return( codaSamples )
} # end function

#===============================================================================

smryMCMC = function(  codaSamples , compVal=0.5 , rope=NULL , 
                      compValDiff=0.0 , ropeDiff=NULL , saveName=NULL ) {
  mcmcMat = as.matrix(codaSamples,chains=TRUE)
  Ntheta = length(grep("theta",colnames(mcmcMat)))
  summaryInfo = NULL
  rowIdx = 0
  for ( tIdx in 1:Ntheta ) {
    parName = paste0("theta[",tIdx,"]")
    summaryInfo = rbind( summaryInfo , 
                         summarizePost( mcmcMat[,parName] , compVal=compVal , ROPE=rope ) )
    rowIdx = rowIdx+1
    rownames(summaryInfo)[rowIdx] = parName
  }
  for ( t1Idx in 1:(Ntheta-1) ) {
    for ( t2Idx in (t1Idx+1):Ntheta ) {
      parName1 = paste0("theta[",t1Idx,"]")
      parName2 = paste0("theta[",t2Idx,"]")
      summaryInfo = rbind( summaryInfo , 
                           summarizePost( mcmcMat[,parName1]-mcmcMat[,parName2] ,
                                          compVal=compValDiff , ROPE=ropeDiff ) )
      rowIdx = rowIdx+1
      rownames(summaryInfo)[rowIdx] = paste0(parName1,"-",parName2)
    }
  }
  if ( !is.null(saveName) ) {
    write.csv( summaryInfo , file=paste(saveName,"SummaryInfo.csv",sep="") )
  }
  show( summaryInfo )
  return( summaryInfo )
}

#===============================================================================

plotMCMC = function( codaSamples , data , compVal=0.5 , rope=NULL , 
                     compValDiff=0.0 , ropeDiff=NULL , 
                     saveName=NULL , saveType="jpg" ) {
  #-----------------------------------------------------------------------------
  # N.B.: This function expects the data to be a data frame, 
  # with one component named y being a vector of integer 0,1 values,
  # and one component named s being a factor of subject identifiers.
  y = data$y
  s = as.numeric(data$s) # converts character to consecutive integer levels
  # Now plot the posterior:
  mcmcMat = as.matrix(codaSamples,chains=TRUE)
  chainLength = NROW( mcmcMat )
  Ntheta = length(grep("theta",colnames(mcmcMat)))
  openGraph(width=3.9*Ntheta,height=3.0*Ntheta)
  par( mfrow=c(Ntheta,Ntheta) )
  for ( t1Idx in 1:(Ntheta) ) {
    for ( t2Idx in (1):Ntheta ) {
      parName1 = paste0("theta[",t1Idx,"]")
      parName2 = paste0("theta[",t2Idx,"]")
      if ( t1Idx > t2Idx) {  
        # plot.new() # empty plot, advance to next
        par( mar=c(3.5,3.5,1,1) , mgp=c(2.0,0.7,0) )
        nToPlot = 700
        ptIdx = round(seq(1,chainLength,length=nToPlot))
        plot ( mcmcMat[ptIdx,parName2] , mcmcMat[ptIdx,parName1] , cex.lab=1.75 ,
               xlab=parName2 , ylab=parName1 , col="skyblue" )
      } else if ( t1Idx == t2Idx ) {
        par( mar=c(3.5,1,1,1) , mgp=c(2.0,0.7,0) )
        postInfo = plotPost( mcmcMat[,parName1] , cex.lab = 1.75 , 
                             compVal=compVal , ROPE=rope , cex.main=1.5 ,
                             xlab=parName1 , main="" )
        includeRows = ( s == t1Idx ) # identify rows of this subject in data
        dataPropor = sum(y[includeRows])/sum(includeRows) 
        points( dataPropor , 0 , pch="+" , col="red" , cex=3 )
      } else if ( t1Idx < t2Idx ) {
        par( mar=c(3.5,1,1,1) , mgp=c(2.0,0.7,0) )
        postInfo = plotPost(mcmcMat[,parName1]-mcmcMat[,parName2] , cex.lab = 1.75 , 
                            compVal=compValDiff , ROPE=ropeDiff , cex.main=1.5 ,
                            xlab=paste0(parName1,"-",parName2) , main="" )
        includeRows1 = ( s == t1Idx ) # identify rows of this subject in data
        dataPropor1 = sum(y[includeRows1])/sum(includeRows1) 
        includeRows2 = ( s == t2Idx ) # identify rows of this subject in data
        dataPropor2 = sum(y[includeRows2])/sum(includeRows2) 
        points( dataPropor1-dataPropor2 , 0 , pch="+" , col="red" , cex=3 )
      }
    }
  }
  #-----------------------------------------------------------------------------  
  if ( !is.null(saveName) ) {
    saveGraph( file=paste(saveName,"Post",sep=""), type=saveType)
  }
}

#===============================================================================


# Load The data 
myData = read.csv("movie_recommendation_models.csv")

fileNameRoot = "movie_models_"
graphFileType = "pdf" 

movies_df = read.csv("movie_recommendation_models.csv")

set.seed(floor(runif(1,max = 100)))

# Lets extract a sample of data to establish priors
sample_df = sample_n(movies_df,nrow(movies_df)/10)
# max_rows =  floor(nrow(movies_df)/20)
# sample_df = movies_df[1:max_rows,]

# probability of a user liking a movie
#prior = length(sample_df$movieId[sample_df$user_liking ==1])/nrow(sample_df)

# parameters for director model
dir_prior = length(sample_df$movieId[sample_df$Is_Top_director ==1])/nrow(sample_df)
dir_hitrate = length(sample_df$movieId[sample_df$director_model == 1])/nrow(sample_df)
dir_fpr = length(sample_df$movieId[(sample_df$user_liking == 0 & sample_df$Is_Top_director == 1)])/nrow(sample_df)

#parameters for imdb rating model
imdb_prior = length(sample_df$movieId[sample_df$imdb_liking ==1])/nrow(sample_df)
imdb_hitrate = length(sample_df$movieId[sample_df$imdb_rate_model == 1])/nrow(sample_df)
imdb_fpr = length(sample_df$movieId[(sample_df$user_liking == 1 & sample_df$imdb_liking == 0)])/nrow(sample_df)


# parameters for action model
action_prior = length(sample_df$movieId[sample_df$is_action ==1])/nrow(sample_df)
action_hitrate = length(sample_df$movieId[sample_df$action_model == 1])/nrow(sample_df)
action_fpr = length(sample_df$movieId[(sample_df$user_liking == 0 & sample_df$is_action == 1)])/nrow(sample_df)


#Taking the remaining rows in the dataframe as new incoming data
new_movies_df = anti_join(movies_df,sample_df)

prior_list = c(dir_prior,imdb_prior,action_prior)



#------------------------------------------------------------------------------- 
# Generate the MCMC chain:
mcmcCoda = genMCMC( data=new_movies_df, prior_list , numSavedSteps=50000 , saveName=fileNameRoot )
#------------------------------------------------------------------------------- 
# Display diagnostics of chain, for specified parameters:
parameterNames = varnames(mcmcCoda) # get all parameter names
for ( parName in parameterNames ) {
  diagMCMC( codaObject=mcmcCoda , parName=parName , 
            saveName=fileNameRoot , saveType=graphFileType )
}
#------------------------------------------------------------------------------- 
# Get summary statistics of chain:
summaryInfo = smryMCMC( mcmcCoda , compVal=NULL , #rope=c(0.45,0.55) ,
                        compValDiff=0.0 , #ropeDiff = c(-0.05,0.05) ,
                        saveName=fileNameRoot )
# Display posterior information:
plotMCMC( mcmcCoda , data=new_movies_df , compVal=NULL , #rope=c(0.45,0.55) ,
          compValDiff=0.0 , #ropeDiff = c(-0.05,0.05) ,
          saveName=fileNameRoot , saveType=graphFileType )
#------------------------------------------------------------------------------- 