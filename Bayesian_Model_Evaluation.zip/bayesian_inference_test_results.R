require("dplyr")


loadData <- function(testResultsFile){
  
  df <- read.csv(testResultsFile)
  return(df)
  
}


bayesianInference <- function(testResults,col_name, prior, fpr, hr){
  
  print(col_name)
  
  prob_list <- c()
  # calculating th posterior of probabilities
  for(num in 1:nrow(testResults)){
    y <- testResults[num,col_name]
    
    if(y==1){
      posterior <- (hr * prior)/((hr*prior)+(fpr*(1-prior)))
    }
    else
    {
      posterior <- ((1-hr)*(prior))/(((prior)*(1-hr))+((fpr)*(1-prior)))
    }
    prob_list <- append(prob_list,posterior)
    prior <- posterior
  }
  
  return(prob_list)
}


plotPosteriors<- function(posteriors, posteriorsFig,plot_title){
  
  require(ggplot2)
  
  df <- data.frame(matrix(ncol = 2, nrow = length(posteriors)))
  colnames(df) <- c("num","results")
  df$num <- 1:length(posteriors)
  df$results <- posteriors
  ggplot(data = df, aes(x=num,y=results)) +
    geom_line(color="red") +
    scale_x_continuous(limits=c(1,length(posteriors)),breaks = c(0,1,2,5,10,20,50,100),trans = "log2") +
    scale_y_continuous(limits=c(0.0,1.0),breaks = c(0.0,0.2,0.4,0.6,0.8,1.0),trans = "identity") +
    xlab("Movie Recommendation Number") +
    ylab("Posterior probability") + ggtitle(plot_title) +
    ggsave(paste(posteriorsFig,".pdf"))
  
}


# Test results file
Data_File = "movie_recommendation_models.csv"

# Posterior probabilitites figure for director model
posteriorsFig_dir = "posteriorsFig_director"

# Posterior probabilities figure for imdb rating model
posteriorsFig_imdb = "posteriorsFig_imdb"

#  posterior probabilities figure for action model
posteriorsFig_action = "posteriorsFig_action"


# Probabilities
#prior = 0.001 # Prior probabilities
fpr = 0.05 # False positive rate



movies_df = loadData(Data_File)

set.seed(floor(runif(1,max = 100)))

# Lets extract a sample of data to establish priors
sample_df = sample_n(movies_df,nrow(movies_df)/10)
# max_rows =  floor(nrow(movies_df)/20)
# sample_df = movies_df[1:max_rows,]

# probability of a user liking a movie
#prior = length(sample_df$movieId[sample_df$user_liking ==1])/nrow(sample_df)

# parameters for director model
dir_prior = length(sample_df$movieId[sample_df$Is_Top_director ==1])/nrow(sample_df)
dir_hitrate = length(sample_df$movieId[sample_df$director_model == 1])/nrow(sample_df)
dir_fpr = length(sample_df$movieId[(sample_df$user_liking == 0 & sample_df$Is_Top_director == 1)])/nrow(sample_df)

#parameters for imdb rating model
imdb_prior = length(sample_df$movieId[sample_df$imdb_liking ==1])/nrow(sample_df)
imdb_hitrate = length(sample_df$movieId[sample_df$imdb_rate_model == 1])/nrow(sample_df)
imdb_fpr = length(sample_df$movieId[(sample_df$user_liking == 1 & sample_df$imdb_liking == 0)])/nrow(sample_df)


# parameters for action model
action_prior = length(sample_df$movieId[sample_df$is_action ==1])/nrow(sample_df)
action_hitrate = length(sample_df$movieId[sample_df$action_model == 1])/nrow(sample_df)
action_fpr = length(sample_df$movieId[(sample_df$user_liking == 0 & sample_df$is_action == 1)])/nrow(sample_df)


#Taking the remaining rows in the dataframe as new incoming data
new_movies_df = anti_join(movies_df,sample_df)

#----------------------------------------------------------------------------------------------------------
# To check the posteriors of director model
#----------------------------------------------------------------------------------------------------------

#testResults = new_movies_df[new_movies_df$Is_Top_director==1,]
testResults = new_movies_df
prior = dir_prior
hr = dir_hitrate
fpr = dir_fpr
col_name = 'director_model'
plot_title = 'For top director model'
posteriors = bayesianInference(testResults,col_name, prior, fpr, hr)

# Takes as input the vector of posterior probabilities and name of the figure (where x axis is the number of data and y axis the corresponding posterior probabilities), and outputs the figure
plotPosteriors(posteriors, posteriorsFig_dir,plot_title)


#-----------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------
# To check the posteriors of imdb_rating model
#----------------------------------------------------------------------------------------------------------

#testResults = new_movies_df[new_movies_df$imdb_liking==1,]
prior = imdb_prior
hr = imdb_hitrate
fpr = imdb_fpr
col_name = 'imdb_rate_model'
plot_title = 'For imdb rate model'
posteriors = bayesianInference(testResults,col_name, prior, fpr, hr)

# Takes as input the vector of posterior probabilities and name of the figure (where x axis is the number of data and y axis the corresponding posterior probabilities), and outputs the figure
plotPosteriors(posteriors, posteriorsFig_imdb,plot_title)

#-------------------------------------------

#----------------------------------------------------------------------------------------------------------
# To check the posteriors of action model
#----------------------------------------------------------------------------------------------------------
#testResults = new_movies_df[new_movies_df$is_action==1,]
prior = action_prior
hr = action_hitrate
fpr = action_fpr
col_name = 'action_model'
plot_title = 'For action model'
posteriors = bayesianInference(testResults,col_name, prior, fpr, hr)

# Takes as input the vector of posterior probabilities and name of the figure (where x axis is the number of data and y axis the corresponding posterior probabilities), and outputs the figure
plotPosteriors(posteriors, posteriorsFig_action,plot_title)

#-------------------------------------------

